
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
@WebServlet("/usingServlet")
public class wishApp extends HttpServlet{
    @Override
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException { 
        PrintWriter out=response.getWriter();
        out.println("<html>");
        out.println("<head></head>");
        out.println("<body>");
        String Message=request.getParameter("Name");
        LocalTime curr=LocalTime.now();
        int hour=curr.getHour();
        if (hour<12) Message="Good Morning "+Message;
        else if (hour>=12 && hour<17) Message="Good Afternoon "+Message;
        else Message="Good Evening "+Message;
        out.println("<h3 align='center'>"+Message+"</h3>");
        out.println("</body>");
        out.println("</html>");
    }
}
