/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package LoginServlet;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // ✅ Predefined username & password
        String validUser = "admin";
        String validPass = "12345";

        if (username.equals(validUser) && password.equals(validPass)) {
            // Create a session
            HttpSession session = request.getSession();
            session.setAttribute("username", username);

            out.println("<h2>Welcome, " + username + "!</h2>");
            out.println("<a href='DashboardServlet'>Go to Dashboard</a><br>");
            out.println("<a href='LogoutServlet'>Logout</a>");
        } else {
            out.println("<h2>Invalid Username or Password!</h2>");
            out.println("<a href='Login.html'>Try Again</a>");
        }
    }
}
