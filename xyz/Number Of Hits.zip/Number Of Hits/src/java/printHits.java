
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
@WebServlet("/hit")
public class printHits extends HttpServlet{
    private static Integer count=0;
    
    @Override
    public void service(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException {
        ServletContext context=request.getServletContext();
        count++;
        context.setAttribute("count",count);
        response.sendRedirect("PrintHits.jsp");
    }
}
