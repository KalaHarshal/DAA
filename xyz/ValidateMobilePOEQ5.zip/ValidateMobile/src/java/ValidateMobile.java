import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/ValidateMobile"})
public class ValidateMobile extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String mobile = request.getParameter("mobile");

        // Regex rule: starts with 6-9, followed by 9 digits (total 10 digits)
        String pattern = "^[6-9][0-9]{9}$";

        out.println("<html><body style='font-family:Arial; text-align:center; margin-top:50px;'>");
        out.println("<h2>Mobile Number Validation Result</h2>");

        if (mobile != null && mobile.matches(pattern)) {
            out.println("<p style='color:green; font-size:18px;'> Valid Mobile Number: " + mobile + "</p>");
        } else {
            out.println("<p style='color:red; font-size:18px;'>Invalid Mobile Number!</p>");
            out.println("<p><b>Rules:</b><br> Must be exactly 10 digits<br> First digit must be between 6 and 9<br> Remaining digits can be 0–9</p>");
        }

        out.println("</body></html>");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirect GET requests to the same validation page
        response.sendRedirect("mobile.html");
    }

    @Override
    public String getServletInfo() {
        return "Servlet to validate 10-digit mobile numbers";
    }
}
