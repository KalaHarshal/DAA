
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
@WebServlet("/register")
public class Register extends HttpServlet{
    @Override
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try {
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
                        ,"root","sami@*123#");
                PreparedStatement pst=con.prepareStatement("insert into Student values(?,?,?,?,?);");
                pst.setString(2,request.getParameter("Name"));
                pst.setString(1,request.getParameter("PRN"));
                pst.setInt(3,Integer.parseInt(request.getParameter("Year")));
                pst.setString(4,request.getParameter("Dept"));
                pst.setString(5,request.getParameter("Sem"));
                pst.executeUpdate();
                pst.close();
                con.close();
                response.sendRedirect("Success.html");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
