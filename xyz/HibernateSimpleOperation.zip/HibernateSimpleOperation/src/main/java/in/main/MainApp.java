/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Admin
 */
public class MainApp {
    public static void main(String[] args) {
        Configuration config=new Configuration();
        config.configure().addAnnotatedClasses(UniversityStudents.class);
        
        SessionFactory sessionFactory=config.buildSessionFactory();
        Session session=sessionFactory.openSession();
        
        UniversityStudents us1=session.get(UniversityStudents.class,"Dhoni");
        System.out.println(us1);
        session.close();
        sessionFactory.close();
    }
}
