package com.example.springjdbc;

import com.example.springjdbc.model.EmployeeDAO;
import com.example.springjdbc.repository.EmployeeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    CommandLineRunner run(EmployeeRepository repo) {
        return args -> {
            System.out.println("\n=== SPRING JDBC CRUD DEMO ===");

            // CREATE
            System.out.println("Inserting new employee...");
            repo.save(new EmployeeDAO(0, "Raju", "raju@mail.com", 9000));

            // READ
            System.out.println("\nAll Employees:");
            repo.findAll().forEach(System.out::println);

            // UPDATE
            System.out.println("\nUpdating employee with ID = 1...");
            repo.update(new EmployeeDAO(1, "Raju Kumar", "raju.kumar@mail.com", 12000));

            System.out.println("\nAfter Update:");
            repo.findAll().forEach(System.out::println);

            // DELETE
            System.out.println("\nDeleting employee with ID = 1...");
            repo.deleteById(1);

            System.out.println("\nAfter Delete:");
            repo.findAll().forEach(System.out::println);
        };
    }
}
