package com.example.springjdbc.repository;

import com.example.springjdbc.model.EmployeeDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmployeeRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int save(EmployeeDAO emp) {
        return jdbcTemplate.update(
                "INSERT INTO employee(name, email, salary) VALUES(?, ?, ?)",
                emp.getName(), emp.getEmail(), emp.getSalary());
    }

    public List<EmployeeDAO> findAll() {
        return jdbcTemplate.query("SELECT * FROM employee",
                new BeanPropertyRowMapper<>(EmployeeDAO.class));
    }

    public int update(EmployeeDAO emp) {
        return jdbcTemplate.update(
                "UPDATE employee SET name=?, email=?, salary=? WHERE id=?",
                emp.getName(), emp.getEmail(), emp.getSalary(), emp.getId());
    }

    public int deleteById(int id) {
        return jdbcTemplate.update("DELETE FROM employee WHERE id=?", id);
    }
}
