import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/Validate"})
public class Validate extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        String pin = request.getParameter("pincode");

        try (PrintWriter out = response.getWriter()) {

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>PIN Code Validation</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h2>PIN Code Validation Result</h2>");

            // Validation logic
            if (pin != null && pin.matches("^[1-9][0-9]{5}$")) {
                out.println("<p style='color:green;'>PIN Code " + pin + " is VALID ✅</p>");
            } else {
                out.println("<p style='color:red;'>PIN Code " + pin + " is INVALID ❌</p>");
                out.println("<p><b>Rules:</b></p>");
                out.println("<ul>");
                out.println("<li>It must be exactly 6 digits</li>");
                out.println("<li>It should not start with 0</li>");
                out.println("<li>Only numeric digits (0–9) are allowed</li>");
                out.println("</ul>");
            }

            out.println("<br><a href='index.html'>Go Back</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}
