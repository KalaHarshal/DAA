/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.main;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

/**
 *
 * @author Admin
**/

@Entity
public class UniversityStudents {
    @Id
    private String name;
    private Integer year;
    private String dept;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    @Override
    public String toString() {
        return "UniversityStudents{" + "name=" + name + ", year=" + year + ", dept=" + dept + '}';
    }
    
}
