import java.sql.*;
import java.util.*;

class LOGIN {
    public static void main(String[] args)throws SQLException {
        String name, address;
        int roll;
        try {
            String url = "jdbc:mysql://localhost:3306/poe";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, "root", "1008");
            Scanner sc = new Scanner(System.in);
            
            while (true) {
                System.out.println("Enter your choice: 1.Insert 2.View 3.Delete 4.Update 5.Close");
                int ch = sc.nextInt();
                switch (ch) {
                    case 1 -> {
                        System.out.println("Enter your name: ");
                        name = sc.next();
                        System.out.println("Enter Roll Number: ");
                        roll = sc.nextInt();
                        sc.nextLine(); // consume newline
                        System.out.println("Enter your address: ");
                        address = sc.nextLine();
                        String insertQuery = "INSERT INTO student(name, rollno, address) VALUES(?,?,?)";
                        PreparedStatement ps = conn.prepareStatement(insertQuery);
                        ps.setString(1, name);
                        ps.setInt(2, roll);
                        ps.setString(3, address);
                        int num = ps.executeUpdate();
                        if (num > 0) {
                            System.out.println("Inserted successfully");
                        } else {
                            System.out.println("Unsuccessful");
                        }
                        ps.close();
                    }
                    case 2 -> {
                        String selectQuery = "SELECT * FROM student";
                        Statement st = conn.createStatement();
                        ResultSet rs = st.executeQuery(selectQuery);
                        System.out.println("name \t rollno \t address\n");
                        while (rs.next()) {
                            String name1 = rs.getString("name");
                            int rno = rs.getInt("rollno");
                            String addr = rs.getString("address");
                            System.out.println(name1 + " \t" + rno + " \t" + addr);
                        }
                        rs.close();
                        st.close();
                    }
                    case 3 -> {
                        System.out.println("Enter roll number to delete data ");
                        int rollNo=sc.nextInt();
                        sc.nextLine();
                        String deleteQuery="DELETE FROM student WHERE rollno= ? ";
                        PreparedStatement ps = conn.prepareStatement(deleteQuery);
                        ps.setInt(1,rollNo);
                        int num = ps.executeUpdate();
                        if (num > 0) {
                            System.out.println("Deletion successfully");
                        } else {
                            System.out.println("Record not present");
                        }
                        ps.close();  
                    }
                    case 4 -> {
                        System.out.println("Enter roll number to change name and address ");
                        int rollNo=sc.nextInt();
                        sc.nextLine();
                        System.out.println("Enter your name: ");
                        String name1 = sc.nextLine();
                        System.out.println("Enter your address: ");
                        String address1 = sc.nextLine();
                        String deleteQuery="UPDATE student SET name=? ,address=? WHERE rollno=?";
                        PreparedStatement ps = conn.prepareStatement(deleteQuery);
                        ps.setInt(3,rollNo);
                        ps.setString(1,name1);
                        ps.setString(2,address1);
                        int num = ps.executeUpdate();
                        if (num > 0) {
                            System.out.println("Update successfully");
                        } else {
                            System.out.println("Error while updating");
                        }
                        ps.close();
                    }
                    case 5 -> {
                        conn.close();
                        sc.close();
                        System.out.println("Connection closed");
                        return; // exit the program
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
                
                            }
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}