/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.example.springjdbc;

/**
 *
 * @author kalah
 */
public class Springjdbc {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
