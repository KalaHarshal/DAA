/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.springjdbc.repository;

import com.example.springjdbc.model.EmployeeDAO;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmployeeRepository {
    private final JdbcTemplate jdbcTemplate;

    public EmployeeRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private RowMapper<EmployeeDAO> rowMapper = (rs, rowNum) -> new EmployeeDAO(
            rs.getInt("id"),
            rs.getString("name"),
            rs.getString("email"),
            rs.getDouble("salary")
    );

    public int save(EmployeeDAO emp) {
        return jdbcTemplate.update("INSERT INTO employee (name, email, salary) VALUES (?, ?, ?)",
                emp.getName(), emp.getEmail(), emp.getSalary());
    }


}
